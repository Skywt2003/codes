#!/usr/bin/env python

import unittest

from cyaron.tests import *

if __name__ == '__main__':
    unittest.main(verbosity=2)
