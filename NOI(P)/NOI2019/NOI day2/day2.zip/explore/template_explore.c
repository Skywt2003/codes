#include "explore.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

void explore(int N, int M) {
	report(0, 1);
}